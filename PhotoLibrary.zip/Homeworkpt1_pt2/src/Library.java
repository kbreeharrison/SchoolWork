/***
 * 
 * @author kyndalharrison
 *
 */
import java.util.ArrayList;
import java.util.HashSet;


public class Library {

	//fields
	private String name;
	private final int id;
	private ArrayList<Photo> photos;
	private HashSet<Album> albums;



	//constructors
	public Library( String name, int id )
	{ 

		this.name = name;
		this.id = id;
		this.photos = new ArrayList<Photo>();
		this.albums = new HashSet<Album>();

	}

	//second constructor
	public Library( String name, int id, ArrayList<Photo> photo, HashSet<Album> albums)
	{
		this.name = name;
		this.id = id;
		this.photos = photo;
		this.albums = albums;
	}


	public static void main(String[] args) {
		//My main method tests had to go 
		
	}

	//methods

	public boolean addPhoto( Photo p )
	{
		if (photos.contains(p) )
			return false;
		else
		{
			photos.add(p);
			return true;
		}
	}

	public boolean hasPhoto( Photo p ) 
	{
		if (photos.contains(p) == true )
			return true;
		else
			return false;

	}

	public boolean deletePhoto( Photo p )
	{	
		if (photos.contains(p) == true)
		{	photos.remove(p);
			for (Album al : this.albums )
			{
				if ( al.hasPhoto(p) == true )
					al.removePhoto(p);
				else
					return false;
			}
			return true;
		}
		else
			return false;
	}	

	public int numPhotos()
	{
		int total = photos.size();
		return total;
	}

	public boolean equals( Object o)
	{
		if ( o == null)
			return false;
		if ( o instanceof Library )
		{
			Library libID = (Library) o;
			if ( this.id == libID.getId())
				return true;
			else 
				return false;
		}
		else 
			return false;
	}

	public String toString()
	{
		return ("The name of this library is " + this.getName() + ", the id is " + this.getId() + ", " + this.getName() + " contains these photos: " + this.getPhotos() + ", and these albums: " + this.getAlbums() );
	}


	public static ArrayList<Photo> commonPhotos( Library a, Library b)
	{
		ArrayList<Photo> commonPhoto = new ArrayList<Photo>();

		for ( int i = 0; i < b.numPhotos(); i++)
		{
			for ( int k = 0; k < a.numPhotos(); k++)
			{
				if ( a.getPhotos().get(k).equals(b.getPhotos().get(i)) == true)
				{
					commonPhoto.add( b.getPhotos().get(i) );
					k = a.numPhotos();
				}
			}
		}
		return commonPhoto;
	}		


	public static double similarity( Library a, Library b)
	{
		double common = ( double )commonPhotos( a, b ).size();

		if ( a.numPhotos() > b.numPhotos() )
			return (double) (common / b.numPhotos() );
		else if ( b.numPhotos() > a.numPhotos())
			return (double) (common / a.numPhotos() );
		else
			return 0.0;
	}

	public ArrayList<Photo> getPhotos( int rating)
	{
		ArrayList<Photo> equalRating = new ArrayList<Photo>();
		
		for ( Photo p : photos)
		{
				if(  p.getRating() >= rating)
					equalRating.add(p);
		}
		return equalRating;	 
	}

	public ArrayList<Photo> getPhotosInYear( int year)
	{
		ArrayList<Photo> equalsYear = new ArrayList<Photo>();
		for ( Photo p : this.photos)
			if (  DateLibrary.getYear( p.getDateTaken() ) == year )
				equalsYear.add(p);
		return equalsYear;
	}

	public ArrayList<Photo> getPhotosInMonth( int month, int year)
	{
		ArrayList<Photo> equalsMonthYear = new ArrayList<Photo>();
		for ( Photo p : this.photos)
			if ( DateLibrary.getMonth( p.getDateTaken() ) == month  && DateLibrary.getYear( p.getDateTaken() ) == year )
				equalsMonthYear.add(p);
		return equalsMonthYear;
	}

	public ArrayList<Photo> getPhotosBetween( String beginDate, String endDate )
	{
		ArrayList<Photo> betweenDates = new ArrayList<Photo>();
		if ( DateLibrary.isValidDate( beginDate) == true & DateLibrary.isValidDate( endDate ) == true)
		{
			for ( Photo p : this.photos)
			{
				if( DateLibrary.compare(beginDate, p.getDateTaken() ) == -1 &&  DateLibrary.compare( p.getDateTaken(), endDate) == -1)
					betweenDates.add(p);
			}
		}
		return betweenDates;
	}
 
	public boolean createAlbum( String albumName)
	{
		if ( getAlbumByName( albumName ) == null )
		{	
			Album alName = new Album( albumName);
			this.albums.add(alName);
			return true;
		}
		else
			return false;
	}


	public boolean removeAlbum( String albumName)
	{

		if ( getAlbumByName( albumName ) != null )
		{	
			this.albums.remove(albumName);
			return true;
		}
		else
			return false;
	}

	public boolean addPhotoToAlbum( Photo p, String albumName)
	{
		for ( Album al : this.albums)
			if ( al.getName() == albumName)
			{
				al.addPhoto(p);
				return true;
			}
			else
				return false;
		return false;
	}

	public boolean removePhotoFromAlbum( Photo p, String albumName)
	{
		for ( Album al : this.albums)
			if( al.getName() == albumName)
			{
				al.removePhoto(p);
				return true;
			}
			else
				return false;
		return false;
	}





	//getters
	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public ArrayList<Photo> getPhotos() {
		return photos;
	}

	public HashSet<Album> getAlbums() {
		return albums;
	}

	private Album getAlbumByName( String albumName ) {

		for ( Album al : this.albums)
		{
			if (al.getName().equals(albumName) )
				return al;
			else
				return null;
		}
		return null; 
	}


	//setters
	public void setPhotos(ArrayList<Photo> photo) {
		this.photos = photo;
	}

	public void setName(String name) {
		this.name = name;
	}

}
