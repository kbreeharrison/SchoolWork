import java.util.HashSet;
/***
 * 
 * @author kyndalharrison
 *
 */
public class Album {  

	private String name;
	private HashSet<Photo> photos;

	//constructor
	public Album( String name)
	{
		this.name = name;
		photos = new HashSet<Photo>();
	}


	public static void main(String[] args) {

	}

	//getters
	public HashSet<Photo> getPhotos() {
		return photos;
	}

	public String getName() {
		return name;
	}

	//setters
	public void setName(String name) {
		this.name = name;
	}

	//other methods
	public boolean addPhoto( Photo p )
	{
		if ( this.photos.contains(p) == true)
			return false;
		else if ( p == null)
			return false;
		else
		{
			this.photos.add(p);
			return true;
		}
	}

	public boolean hasPhoto( Photo p)
	{
		if ( this.photos.contains(p))
			return true;
		else
			return false;
	}

	public boolean removePhoto( Photo p )
	{
		if ( this.photos.contains(p) == true)
		{
			this.photos.remove(p);
			return true;
		}
		else
			return false;
	}

	public int numPhotos()
	{
		return photos.size();
	}

	public boolean equals( Object o)
	{
		if (  o instanceof Album )
		{
			Album object = (Album) o;
			if( object.getName() == this.getName())
				return true;
			else
				return false;
		}
		else 
			return false; 
	}

	public String toString()
	{
		return " The album name is " + getName() + "\nThe album contains:  " + getPhotos();
	}

	public int hashCode()
	{
		return this.name.hashCode();
	}





}
