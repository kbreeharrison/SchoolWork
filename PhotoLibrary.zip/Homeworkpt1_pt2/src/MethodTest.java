/***
 * 
 * @author kyndalharrison
 *
 */
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Test;

public class MethodTest {
	
	Photo p1 = new Photo( "KeyWest", "Aug 2019");
	Photo p2 = new Photo( "Key West", "Boats", "1956-02-11", 5);
	Photo p3 = new Photo( "BlueLagoon", "Beach", "1956-02-11", 2);
	Photo p4 = new Photo( "BlueLagoon", "Beach");
	Photo p5 = new Photo( "Sunday", "End of Reunion", "1956-02-11", 3);
	
	
	
	Photo q = new Photo( "May Flowes", "April Showers", "2000-05-10", 3 );
	Photo q1 = new Photo( "June Flowes", "May Showers", "2000-06-10", 3 );
	Photo q2 = new Photo( "Flowes", "Showers", "2000-05-10", 4 );
	Photo q3 = new Photo( "June Flowers", " ", "2000-06-17", 2 );
	Photo q4 = new Photo( "June Flowers", "May Showers", "2000-06-10", 4);
	
	Album qPhotos = new Album( "qPhotos" );
	ArrayList<Photo> photoList = new ArrayList<Photo>();
	HashSet<Album> albumHash = new HashSet<Album>();
	
	Library tester = new Library( "TestLibrary", 3421, photoList, albumHash );
	
	Album newPhotos = new Album( "NewPhotos");
	ArrayList<Photo> newList = new ArrayList<Photo>();
	HashSet<Album> newAlbum = new HashSet<Album>();
	
	Library testerb = new Library( "TesterLibrary", 6453, newList, newAlbum);
	Library testerc = new Library( "TLibrary", 6413, newList, newAlbum);
	
	@Test
	public void testGetPhotos() {
		
		//test 1
		photoList.add(p1);
		photoList.add(p2);
		photoList.add(p3);
		photoList.add(p4);
		photoList.add(p5);
		
		ArrayList<Photo> actual = tester.getPhotos( 2 );
		
		ArrayList<Photo> expected = new ArrayList<Photo>();
		expected.add( p2);
		expected.add(p3);
		expected.add(p5);
		
		assertEquals( "correct", expected, actual);
		
		
		//test 2
		
		ArrayList<Photo> actual1 = tester.getPhotos( 6);
		ArrayList<Photo> expected1 = new ArrayList<Photo>();

		
		assertEquals( "correct", expected1, actual1 );
	
	} 
		  
		
	
	@Test
	public void testPhotosInMonth() {
		
		photoList.add(p1);
		photoList.add(p2);
		photoList.add(p3);
		photoList.add(p4);
		photoList.add(p5);
		photoList.add(q);
		photoList.add(q1);
		photoList.add(q2);
		photoList.add(q3);
		photoList.add(q4);
		
		//test 1
		ArrayList<Photo> actual = tester.getPhotosInMonth(05, 2000);
		
		ArrayList<Photo> expected = new ArrayList<Photo>();
		expected.add(q);
		expected.add(q2);
		
		assertTrue( "correct", expected.equals(actual));
		
		//test 2
		ArrayList<Photo> actual1 = tester.getPhotosInMonth( 02, 1956);
		ArrayList<Photo> expected1 = new ArrayList<Photo>();
		expected1.add(p2);
		expected1.add(p3);
		expected1.add(p5);
		
		assertEquals( "correct", expected1, actual1 );
	}

	
	@Test
	public void testPhotosBetween() {
		photoList.add(p1);
		photoList.add(p2);
		photoList.add(p3);
		photoList.add(p4);
		photoList.add(p5);
		photoList.add(q);
		photoList.add(q1);
		photoList.add(q2);
		photoList.add(q3);
		photoList.add(q4);
		
		//test 1
		ArrayList<Photo> actual = tester.getPhotosBetween("2000-01-01", "2000-05-31");
		ArrayList<Photo> expected = new ArrayList<Photo>();
		expected.add(q);
		expected.add(q2);
		
		assertEquals( "correct", expected, actual);
		
		//test 2
		ArrayList<Photo> actual1 = tester.getPhotosBetween( "1956-02-01", "2000-01-01");
		ArrayList<Photo> expected1= new ArrayList<Photo>();
		expected1.add(p2);
		expected1.add(p3);
		expected1.add(p5);
		
		assertEquals( "correct", expected1, actual1);
	}
	
	@Test
	public void testDeletePhoto() {
		photoList.add(p1);
		photoList.add(p2);
		photoList.add(p3);
		photoList.add(p4);
		photoList.add(p5);
		photoList.add(q);
		photoList.add(q1);
		photoList.add(q2);
		photoList.add(q3);
		photoList.add(q4);
		
		qPhotos.addPhoto(q);
		qPhotos.addPhoto(q1);
		qPhotos.addPhoto(q2);
		qPhotos.addPhoto(q3);
		qPhotos.addPhoto(q4);
		 
		albumHash.add(qPhotos);
		
		//test 1
		boolean result = tester.deletePhoto(q);
		boolean expected = true;
		
		assertEquals( "correct", expected, result);
	
		//test 2
		
		boolean result1 = tester.deletePhoto(p2);
		boolean expected1 = false;
		
		assertEquals( "correct", expected1, result1);
	}
	
	@Test
	public void testSimilarity() {
		
		photoList.add(p1);
		photoList.add(p2);
		photoList.add(p3);
		photoList.add(p4);
		photoList.add(p5);
		photoList.add(q);
		photoList.add(q1);
		photoList.add(q2);
		photoList.add(q3);
		photoList.add(q4);
		
		newList.add(q1);
		newList.add(p1);
		newList.add(q2);
		newList.add(p1);
		newList.add(q3);
		
		double actual = Library.similarity(tester, testerb);
		double expected = 1.0;
		
		assertEquals( "correct", expected, actual, .001);
		
		double result = Library.similarity(testerc, testerb);
		double expected1 = 0.0; 
		
		assertEquals( "correct" , expected1, result, .001 );
		
	}

}
