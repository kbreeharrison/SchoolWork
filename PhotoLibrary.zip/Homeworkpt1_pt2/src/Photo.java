/***
 * 
 * @author kyndalharrison
 *
 */
public class Photo {


	//fields
	private final String caption;
	private final String filename;
	private int rating;
	private String dateTaken;


	//constructors
	public Photo( String filename , String caption )
	{
		rating = 1;
		this.filename = filename;
		this.caption = caption;
		dateTaken = "1901-01-01";
	}

	//second constructor
	public Photo( String caption, String filename, String dateTaken, int rating )
	{
		this.filename = filename;
		this.caption = caption;
	
		if ( DateLibrary.isValidDateFormat(dateTaken) == false )
				this.dateTaken = "1901-01-01";
		else
			this.dateTaken = dateTaken;

		if ( rating < 1 || rating > 5)
			this.rating = 1;
		else
			this.rating = rating;
	}



	//main method
	public static void main(String[] args) {

//				Photo p1 = new Photo( "KeyWest", "Aug 2019");
//				
//				Photo p2 = new Photo( "Key West", "Boats", 6);
//				
//				Photo p3 = new Photo( "BlueLagoon", "Beach");
//				
//				Photo p4 = new Photo( "BlueLagoon", "Beach", 4);
//				
//				Photo p5 = new Photo( "Sunday", "End of Reunion");
		//		
		//		Photo p6 = new Photo( "Sunday", "Church", 0);
		//		
		//tester
		//		
		//		System.out.println( p1.setRating( p1.getRating()) );
		//		System.out.println( p2.setRating( p2.getRating()) );
		//		
		//		System.out.println( p1.toString() );
		//		System.out.println( p2.toString() );
		//		
		//		System.out.println( p1.equals(p6));
		//		System.out.println( p3.equals(p4));
		//		System.out.println( p5.equals(p3));
		//		
		//		


	}


	//toString()
	public String toString()
	{
		return ( "The file name is " + this.getFilename() + ", the caption is " + this.getCaption() + ", and the rating is " + this.getRating() + ".");
	}


	//equals()
	public boolean equals( Object o )
	{
		if ( o == null ) 
			return false;
		if ( o instanceof Photo)
		{
			Photo pict = (Photo) o;
			if ( pict.getCaption( ) == this.getCaption() && pict.getFilename() == this.getFilename() )
				return true;
			else
				return false;
		}
		else
			return false;
	}
	//hashCode
	public int hashCode()
	{ 
		return this.filename.hashCode();
	}

	//getters
	public String getCaption() {
		return caption;
	}


	//getters
	public String getFilename() {
		return filename;
	}


	public int getRating() {
		return rating;
	}

	public String getDateTaken() {

		return dateTaken;
	}


	//setters
	public boolean setRating(int newRating) 
	{
		if ( this.getRating() < 1 || this.getRating() > 5)
			return false;
		else
			return true;
	}


}
